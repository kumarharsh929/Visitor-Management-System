
<?php include('vtr_header.php');?>
<?php include('vtr_top_menu.php');?>
<?php include('vtr_side_nav.php');?>
   <p>
     <h1 style="color:#fff; margin-top: 15%; margin-left: 34%;">
       <b>WELCOME</b>
     </h1>
   </p>
<?php include('vtr_footer.php');?>